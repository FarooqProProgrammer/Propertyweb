
from PIL import Image
import os

def compress_image(input_path, output_path, quality=80):
    with Image.open(input_path) as image:
        image.save(output_path, optimize=True, quality=quality)

    input_size = os.path.getsize(input_path)
    output_size = os.path.getsize(output_path)
    compression_ratio = round((output_size / input_size) * 100, 2)

    print(f"Compressed image saved at: {output_path}")
    print(f"Original size: {input_size} bytes")
    print(f"Compressed size: {output_size} bytes")
    print(f"Compression ratio: {compression_ratio}%")

# Example usage
input_image_path = "turkish_citizenship_by_investment.jpeg"
output_image_path = "turkish_citizenship_by_investment_new.jpeg"
compression_quality = 80

compress_image(input_image_path, output_image_path, compression_quality)
